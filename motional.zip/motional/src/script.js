// ============================

// PRELOADER FADE OUT

// ============================

window.addEventListener('load', () => {

    const preloader = document.querySelector('.preloader');

    preloader.style.opacity = '0';

    preloader.style.transition = 'opacity 0.8s ease';

    setTimeout(() => {

        preloader.style.display = 'none';

    }, 800);

});

// ============================

// MOBILE MENU TOGGLE

// ============================

const menuToggle = document.querySelector('.menu-toggle');

const navLinks = document.querySelector('.nav-links');

menuToggle.addEventListener('click', () => {

    navLinks.classList.toggle('active');

});

document.querySelectorAll('.nav-links a').forEach(link => {

    link.addEventListener('click', () => {

        navLinks.classList.remove('active');

    });

});

// ============================

// SMOOTH SCROLL FOR INTERNAL LINKS

// ============================

document.querySelectorAll('a[href^="#"]').forEach(anchor => {

    anchor.addEventListener('click', function(e) {

        e.preventDefault();

        const target = document.querySelector(this.getAttribute('href'));

        target.scrollIntoView({ behavior: 'smooth', block: 'start' });

    });

});

// ============================

// HERO INTERACTIVE SHAPES (MOUSE MOVEMENT)

// ============================

const shapes = document.querySelectorAll('.moving-shapes .shape');

document.addEventListener('mousemove', e => {

    const x = (e.clientX / window.innerWidth - 0.5) * 30;

    const y = (e.clientY / window.innerHeight - 0.5) * 30;

    shapes.forEach((shape, index) => {

        const speed = (index + 1) * 5;

        shape.style.transform = `translate(${x * speed}px, ${y * speed}px) rotate(${x * 10}deg)`;

    });

});

// ============================

// OPTIONAL: ADD SHADOW & SCALE EFFECT ON BUTTONS

// ============================

const buttons = document.querySelectorAll('.btn, .contact button');

buttons.forEach(button => {

    button.addEventListener('mouseenter', () => {

        button.style.transform = 'scale(1.1)';

        button.style.boxShadow = '0 10px 25px rgba(0,224,255,0.6)';

        button.style.transition = '0.3s';

    });

    button.addEventListener('mouseleave', () => {

        button.style.transform = 'scale(1)';

        button.style.boxShadow = '';

    });

});

// ============================

// OPTIONAL: CARD HOVER EFFECTS

// ============================

const cards = document.querySelectorAll('.services .card, .projects .project-card');

cards.forEach(card => {

    card.addEventListener('mouseenter', () => {

        card.style.transform = 'translateY(-10px) scale(1.05)';

        card.style.boxShadow = '0 15px 30px rgba(0,224,255,0.6)';

    });

    card.addEventListener('mouseleave', () => {

        card.style.transform = 'translateY(0) scale(1)';

        card.style.boxShadow = '';

    });

});